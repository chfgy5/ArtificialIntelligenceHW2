# To run the program for DFGS and IDTS
	run main.py
# To run the program for A*
	run a-star-python.py
